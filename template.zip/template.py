from tools import *


class ProdLayer:
    """ Template example for a class implementing a single layer.
        This example performs coordinate-wise multiplication. """
    
    def forward(self, x: np.array, w: np.array) -> np.array:
        """
        :param x: [N x d] -- layer input of N data points with d dimensions
        :param w: [d] -- d weights
        :return: layer output y = x * w
        """
        self.x = x # remember x
        self.w = w # remember w
        return x * w[np.newaxis, :] # multiply each data point features coordinate-wise with w
    
    def backward(self, dy: np.array) -> Tuple[np.array, np.array]:
        """
        :param dy: [N x d] -- gradient with respect to the layer output
        :return: tuple of gradients in the layer inputs (dx, dw)
        """
        dx = dy * self.w[np.newaxis, :]
        dw = (dy * self.x).sum(axis=0)
        return (dx, dw)


class SumLayer:
    """ Another example, implementing summation of all features operation """

    def forward(self, x: np.array) -> np.array:
        """
        :param x: [N x d] -- layer input of N data points with d dimensions
        :return y: [N] -- sum of x along dimension 1
        """
        self.x = x # remember x
        y = x.sum(axis=1)
        return y

    def backward(self, dy: np.array) -> np.array:
        """
        :param dy: [N] -- gradient with respect to the layer output
        :return: gradients in the layer input (dx) [N x d]
        """
        dx = np.empty_like(self.x)
        dx[:,:] = dy[:,np.newaxis]
        return dx

class MSELoss:
    """ Template example for the loss function. This example shows Mean Squared Error loss, suitable for regression. """
    
    def forward(self, x: np.array, y: np.array) -> float:
        """
        :param x: [N] -- scores of N data points
        :param y: [N] -- target labels
        :return: loss [] -- scalar loss
        """
        self.delta = x - (2 * y - 1)  # compute and remember difference
        loss = (self.delta ** 2).mean()
        return loss
    
    def backward(self) -> np.array:
        """
        :input: no input to the top gradient function
        :return: gradient in the layer input dx
        (gradient in target y is not needed)
        """
        dx = 2 / self.delta.shape[0] * self.delta
        return dx


class MyNet:
    """ Template example for the network """
    
    def __init__(self, input_size, hidden_size):
        # name is needed for printing
        self.name = f'Net-example-hidden-{hidden_size}'
        # define arrays that will be parameters of the network
        self.params = dotdict()  # same as dict but with additional access through dot notation
        self.params.w1 = np.random.rand(input_size)
        self.params.w2 = np.random.rand(input_size)
        # define some layers
        self.layer1 = ProdLayer()
        self.layer2 = ProdLayer()
        self.layer3 = SumLayer()
        self.loss = MSELoss()
    
    def score(self, x: np.array) -> np.array:
        """
        Return log odds (logits) of predictive probability p(y|x) of the network
        *
        :param x: np.array [N x d], N number of points, d dimensionality of the input features
        :return: y: np.array [N] predicted scores of class 1 for all points
        """
        x1 = self.layer1.forward(x, self.params.w1)
        x2 = self.layer2.forward(x1, self.params.w2)
        s = self.layer3.forward(x2)
        return s
    
    def classify(self, x: np.array) -> np.array:
        """
        Make class prediction for the given gata
        *
        :param x: np.array [N x d], N number of points, d dimensionality of the input features
        :return: y: np.array [N] class 0 or 1 per input point
        """
        return self.score(x) > 0
    
    def mean_loss(self, x, y):  # forward at training time
        """
        Compute the total loss on the training data
        *
        :param train_data: tuple(x,y)
        x [N x d] np.array data points
        y [N] np.array their classes
        :return: total loss to optimize
        """
        s = self.score(x)
        return self.loss.forward(s, y)

    def backward(self):
        """
        Compute gradients in all parameters
        *
        :return: dict mapping parameters to their gradients for grad descent
        """
        grads = dotdict()
        # backprop loss
        grads.score = self.loss.backward()
        # backprop layer 3 (summation)
        grads.x2 = self.layer3.backward(grads.score)
        # backprop layer 2 (product)
        grads.x1, grads.w2 = self.layer2.backward(grads.x2)
        # backprop layer 1 (product)
        _, grads.w1 = self.layer1.backward(grads.x1)
        return grads

    def check_grad(self, train_data, step_size=0.00001):
        pass

    def train(self, train_data, epochs=100, step_size=0.1):
        """
        Train the model using gradient descent
        *
        :param train_data: tuple (x,y) of trianing data
        :param epochs: number of epochs for gradient descent
        :param step_size: step size in gradient descent
        """
        x, y = train_data
        for epoch in range(epochs):
            # compute loss of the train data
            L = self.mean_loss(x, y)
            # compute gradients in all parameter
            grads = self.backward()
            # make a grad descent step
            for (k, p) in self.params.items():
                p -= step_size * grads[k]
                # print current loss, should be going down
            print(L)


if __name__ == "__main__":

    # use provided class to generate data, visualize data and decision boundaries
    model = G2Model()
    train_data = model.generate_sample(200)
    test_data = model.generate_sample(10000)

    # create our network
    net = MyNet(2, hidden_size=5)

    net.check_grad(train_data)

    print("Training net:")
    net.train(train_data, epochs=100, step_size=0.1)

    err_rate = model.test_error(net, test_data)
    print(f"Achieved error rate:{err_rate * 100:.3f}%")
    err_rate0 = model.test_error(model, test_data)
    print(f"GT error rate:{err_rate0 * 100:.3f}%")

    #
    print(f"Drawing -- see {net.name}.pdf")
    model.plot_boundary(train_data, net)
